/// @DnDAction : YoYo Games.Common.Variable
/// @DnDVersion : 1
/// @DnDHash : 026431E4
/// @DnDArgument : "var" "points"
points = 0;

/// @DnDAction : YoYo Games.Instances.Create_Instance
/// @DnDVersion : 1
/// @DnDHash : 67B63969
/// @DnDArgument : "objectid" "obj_wallpaper"
/// @DnDSaveInfo : "objectid" "obj_wallpaper"
instance_create_layer(0, 0, "Instances", obj_wallpaper);