/// @DnDAction : YoYo Games.Common.Variable
/// @DnDVersion : 1
/// @DnDHash : 73EA9532
/// @DnDInput : 2
/// @DnDArgument : "expr" "10"
/// @DnDArgument : "expr_1" "obj_player.image_angle"
/// @DnDArgument : "var" "speed"
/// @DnDArgument : "var_1" "direction"
speed = 10;
direction = obj_player.image_angle;

/// @DnDAction : YoYo Games.Instances.Set_Sprite
/// @DnDVersion : 1
/// @DnDHash : 7363B0D0
/// @DnDArgument : "imageind" "random_range(1,8)"
/// @DnDArgument : "spriteind" "spr_bullet"
/// @DnDSaveInfo : "spriteind" "spr_bullet"
sprite_index = spr_bullet;
image_index = random_range(1,8);